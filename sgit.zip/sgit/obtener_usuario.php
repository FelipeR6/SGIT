<?php
session_start();

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(["error" => "No hay usuario autenticado"]);
    exit;
}

$response = [
    "nombre" => $_SESSION['nombre'] ?? "Usuario",
    "id_rol" => $_SESSION['id_rol'] ?? null, 
    "nombre_rol" => $_SESSION['nombre_rol'] ?? "Desconocido"
];

echo json_encode($response);
?>
