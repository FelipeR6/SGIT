<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'db_connect.php';

// Función para iniciar sesión
function loginUser($usuario, $password, $rol) {
    global $conn;
    
    // Prevenir inyección SQL
    $usuario = $conn->real_escape_string($usuario);
    
    // Consulta con INNER JOIN para obtener el nombre del rol
    $sql = "SELECT u.Id_Usuario, u.Usuario, u.Nombre_Usuario_1, u.Apellidos_Usuario_1, 
                   u.Id_Rol, r.Nombre_Rol
            FROM usuario u
            INNER JOIN rol r ON u.Id_Rol = r.Id_Rol
            WHERE u.Usuario = ? AND u.Contraseña = ? AND u.Id_Rol = ?";
    
    $stmt = $conn->prepare($sql);
    
    // Verificar si la consulta se preparó correctamente
    if (!$stmt) {
        die("Error en la consulta SQL: " . $conn->error);
    }

    $stmt->bind_param("ssi", $usuario, $password, $rol);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        // Guardar datos en la sesión
        $_SESSION['user_id'] = $user['Id_Usuario'];
        $_SESSION['username'] = $user['Usuario'];
        $_SESSION['nombre'] = $user['Nombre_Usuario_1'] . ' ' . $user['Apellidos_Usuario_1'];
        $_SESSION['id_rol'] = $user['Id_Rol'];
        $_SESSION['nombre_rol'] = $user['Nombre_Rol']; 
        
        return true;
    } else {
        return false;
    }
}



// Función para registrar usuario
function registerUser($usuario, $nombre1, $nombre2, $apellido1, $apellido2, $telefono1, $telefono2, $correo, $password, $rol) {
    global $conn;
    
    // Verificar si el usuario ya existe
    $check = $conn->prepare("SELECT * FROM usuario WHERE Usuario = ? OR Correo_Usuario = ?");
    $check->bind_param("ss", $usuario, $correo);
    $check->execute();
    $result = $check->get_result();
    
    if ($result->num_rows > 0) {
        return "El usuario o correo ya existe";
    }
    
    // Insertar nuevo usuario
    $sql = "INSERT INTO usuario (Usuario, Nombre_Usuario_1, Nombre_Usuario_2, Apellidos_Usuario_1, Apellidos_Usuario_2, 
            Telefono_1_Usuario, Telefono_2_Usuario, Correo_Usuario, Contraseña, Id_Rol) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssssi", $usuario, $nombre1, $nombre2, $apellido1, $apellido2, $telefono1, $telefono2, $correo, $password, $rol);
    
    if ($stmt->execute()) {
        return "success";
    } else {
        return "Error: " . $stmt->error;
    }
}

// Función para recuperar contraseña
function recoverPassword($correo) {
    global $conn;
    
    // Verificar si el correo existe
    $check = $conn->prepare("SELECT * FROM usuario WHERE Correo_Usuario = ?");
    $check->bind_param("s", $correo);
    $check->execute();
    $result = $check->get_result();
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        // En un sistema real, aquí enviarías un correo con un token
        // Para este ejemplo, simplemente devolvemos la contraseña
        return $user['Contraseña'];
    } else {
        return false;
    }
}

// Función para verificar si el usuario está logueado
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Función para cerrar sesión
function logout() {
    session_unset();
    session_destroy();
}
?>