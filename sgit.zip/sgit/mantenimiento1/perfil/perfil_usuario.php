<?php
// Iniciar sesión para manejar la autenticación
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['id_usuario'])) {
  // Redirigir al login si no hay sesión activa
  header("Location: login.php");
  exit();
}

// Conexión a la base de datos
$servidor = "localhost";
$usuario_db = "root";
$password_db = "";
$base_datos = "sgit";

$conexion = new mysqli($servidor, $usuario_db, $password_db, $base_datos);

// Verificar conexión
if ($conexion->connect_error) {
  die("Error de conexión: " . $conexion->connect_error);
}

// Obtener ID del usuario actual
$id_usuario = $_SESSION['id_usuario'];

// Determinar el nombre de la columna ID en la tabla usuario
$id_column = null;
$sql_columnas = "SHOW COLUMNS FROM usuario";
$resultado_columnas = $conexion->query($sql_columnas);

if ($resultado_columnas) {
  while ($columna = $resultado_columnas->fetch_assoc()) {
    if ($columna['Key'] == 'PRI') {
      $id_column = $columna['Field'];
      break;
    }
  }
}

// Si no se encontró, usar el valor de la sesión como nombre de columna
if (!$id_column) {
  // Intentar con nombres comunes para ID
  $posibles_ids = ['id_usuario', 'usuario_id', 'id', 'codigo', 'cod_usuario'];
  foreach ($posibles_ids as $posible_id) {
    $check_sql = "SHOW COLUMNS FROM usuario LIKE '$posible_id'";
    $check_result = $conexion->query($check_sql);
    if ($check_result && $check_result->num_rows > 0) {
      $id_column = $posible_id;
      break;
    }
  }
}

// Si aún no se encontró, usar la primera columna
if (!$id_column) {
  $first_col_sql = "SHOW COLUMNS FROM usuario LIMIT 1";
  $first_col_result = $conexion->query($first_col_sql);
  if ($first_col_result && $first_col_result->num_rows > 0) {
    $first_col = $first_col_result->fetch_assoc();
    $id_column = $first_col['Field'];
  } else {
    die("No se pudo determinar la estructura de la tabla usuario");
  }
}

// Consulta para obtener información del usuario
$sql_usuario = "SELECT * FROM usuario WHERE $id_column = ?";
$stmt_usuario = $conexion->prepare($sql_usuario);
$stmt_usuario->bind_param("i", $id_usuario);
$stmt_usuario->execute();
$resultado_usuario = $stmt_usuario->get_result();
$usuario = $resultado_usuario->fetch_assoc();

// Verificar si existe una tabla de préstamos
$tabla_prestamos = null;
$posibles_tablas = ['prestamos', 'prestamo', 'prestamo_usuario', 'prestamo_usuarios'];

foreach ($posibles_tablas as $posible_tabla) {
  $check_tabla_sql = "SHOW TABLES LIKE '$posible_tabla'";
  $check_tabla_result = $conexion->query($check_tabla_sql);
  if ($check_tabla_result && $check_tabla_result->num_rows > 0) {
    $tabla_prestamos = $posible_tabla;
    break;
  }
}

// Si se encontró una tabla de préstamos, buscar la columna que relaciona con usuario
$id_usuario_en_prestamos = null;
$resultado_prestamos = null;

if ($tabla_prestamos) {
  $columnas_prestamos_sql = "SHOW COLUMNS FROM $tabla_prestamos";
  $columnas_prestamos_result = $conexion->query($columnas_prestamos_sql);

  if ($columnas_prestamos_result) {
    while ($columna = $columnas_prestamos_result->fetch_assoc()) {
      $field_lower = strtolower($columna['Field']);
      if (strpos($field_lower, 'usuario') !== false || strpos($field_lower, 'user') !== false) {
        $id_usuario_en_prestamos = $columna['Field'];
        break;
      }
    }
  }

  // Si no se encontró, intentar con el mismo nombre de la columna ID en usuario
  if (!$id_usuario_en_prestamos && $id_column) {
    $check_id_sql = "SHOW COLUMNS FROM $tabla_prestamos LIKE '$id_column'";
    $check_id_result = $conexion->query($check_id_sql);
    if ($check_id_result && $check_id_result->num_rows > 0) {
      $id_usuario_en_prestamos = $id_column;
    }
  }

  // Si se encontró la columna de relación, consultar los préstamos
  if ($id_usuario_en_prestamos) {
    $sql_prestamos = "SELECT * FROM $tabla_prestamos WHERE $id_usuario_en_prestamos = ?";
    $stmt_prestamos = $conexion->prepare($sql_prestamos);
    $stmt_prestamos->bind_param("i", $id_usuario);
    $stmt_prestamos->execute();
    $resultado_prestamos = $stmt_prestamos->get_result();
  }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Perfil de Usuario</title>
  <link rel="stylesheet" href="prueba2.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap"
    rel="stylesheet" />
  <style>
    /* Fondo general y centrado principal */
    body,
    html {
      height: 100%;
      margin: 0;
      padding: 0;
      font-family: 'Segoe UI', sans-serif;
      background-color: #f4f6f8;
      display: flex;
      justify-content: center;
      align-items: flex-start;
      /* Usa center para centrar verticalmente también */
    }

    /* Contenedor general */
    .main-container {
      width: 100%;
      max-width: 900px;
      padding: 40px 20px;
    }

    /* Secciones con caja blanca */
    .profile-section,
    .loans-section {
      background-color: #ffffff;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
      margin-bottom: 30px;
      padding: 20px;
    }

    /* Títulos */
    .profile-section h1,
    .loans-section h2 {
      text-align: center;
      margin-bottom: 20px;
      color: #333;
    }

    /* Fila de info de usuario */
    .info-row {
      display: flex;
      justify-content: space-between;
      padding: 10px 0;
      border-bottom: 1px solid #e0e0e0;
    }

    .info-label {
      font-weight: 600;
      color: #555;
      width: 45%;
    }

    .info-value {
      color: #222;
      width: 55%;
      text-align: right;
    }

    .password-hidden {
      font-style: italic;
      color: #999;
    }

    /* Tabla */
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 15px;
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
    }

    th,
    td {
      padding: 12px;
      border: 1px solid #ddd;
      text-align: left;
    }

    thead {
      background-color: #f0f0f0;
    }

    /* Botón */
    .change-password-button {
      display: block;
      margin: 0 auto;
      padding: 10px 20px;
      background-color: #007bff;
      color: white;
      text-decoration: none;
      border-radius: 8px;
      text-align: center;
      margin-top: 20px;
      transition: background-color 0.3s;
    }

    .change-password-button:hover {
      background-color: #0056b3;
    }
  </style>
</head>

<body>
<aside class="sidebar">
    <div class="sidebar-header">
      <h2>SGIT</h2>
      <div class="theme-toggle">
        <i class="fa-solid fa-sun sun"></i>
        <label class="switch">
          <input type="checkbox" id="theme-toggle" />
          <span class="slider"></span>
        </label>
        <i class="fa-solid fa-moon moon"></i>
      </div>
    </div>

    <nav class="sidebar-nav">
      
    <div class="nav-item">
          <div class="nav-link-wrapper">
            <div class="item-glow inventory-glow"></div>
            <a href="dashboard_mantenimiento.HTML" class="nav-link-front">
              <i class="fas fa-home nav-icon inventory-icon"></i>
              <span>Inicio</span>
            </a>
            <a href="dashboard_mantenimiento.HTML" class="nav-link-back">
              <i class="fas fa-home nav-icon inventory-icon"></i>
              <span>Inicio</span>
            </a>
          </div>
        </div>
      <div class="nav-item">
        <div class="nav-link-wrapper">
          <div class="item-glow inventory-glow"></div>
          <a href="../inventario.html" class="nav-link-front">
            <i class="fas fa-box nav-icon inventory-icon"></i>
            <span>Inventario</span>
          </a>
          <a href="../inventario.html" class="nav-link-back">
            <i class="fas fa-box nav-icon inventory-icon"></i>
            <span>Inventario</span>
          </a>
        </div>
      </div>

      <div class="nav-item">
        <div class="nav-link-wrapper">
          <div class="item-glow maintenance-glow"></div>
          <a href="../prestamo.html" class="nav-link-front">
            <i class="fas fa-tools nav-icon maintenance-icon"></i>
            <span>Prestamo</span>
          </a>
          <a href="../prestamo.html" class="nav-link-back">
            <i class="fas fa-tools nav-icon maintenance-icon"></i>
            <span>Prestamo</span>
          </a>
        </div>
      </div>

      <div class="nav-item">
        <div class="nav-link-wrapper">
          <div class="item-glow logout-glow"></div>
          <a href="../../index.html" class="nav-link-front">
            <i class="fas fa-sign-out-alt nav-icon logout-icon"></i>
            <span>Cerrar Sesión</span>
          </a>
          <a href="../../index.html" class="nav-link-back">
            <i class="fas fa-sign-out-alt nav-icon logout-icon"></i>
            <span>Cerrar Sesión</span>
          </a>
        </div>
      </div>
    </nav>
  </aside>

  <div class="container">
    <div class="logout-link">
      <a href="logout.php">Cerrar sesión</a>
    </div>

    <div class="profile-section">
      <h1>Perfil de Usuario</h1>

      <?php if ($usuario): ?>
        <?php foreach ($usuario as $campo => $valor): ?>
          <?php if ($campo != 'password' && $campo != $id_column): ?>
            <div class="info-row">
              <div class="info-label"><?php echo ucfirst($campo); ?>:</div>
              <div class="info-value"><?php echo htmlspecialchars($valor); ?></div>
            </div>
          <?php endif; ?>
        <?php endforeach; ?>

        <div class="info-row">
          <div class="info-label">Contraseña:</div>
          <div class="info-value password-hidden">********</div>
        </div>
      <?php else: ?>
        <p>No se encontró información del usuario.</p>
      <?php endif; ?>
    </div>

    <div class="loans-section">
      <h2>Préstamos Solicitados</h2>

      <?php if ($resultado_prestamos && $resultado_prestamos->num_rows > 0): ?>
        <table>
          <thead>
            <tr>
              <?php
              $primera_fila = $resultado_prestamos->fetch_assoc();
              $resultado_prestamos->data_seek(0); // Reiniciar el puntero
            
              foreach ($primera_fila as $campo => $valor):
                if ($campo != $id_usuario_en_prestamos): // No mostrar la columna de ID de usuario
                  ?>
                  <th><?php echo ucfirst($campo); ?></th>
                  <?php
                endif;
              endforeach;
              ?>
            </tr>
          </thead>
          <tbody>
            <?php while ($prestamo = $resultado_prestamos->fetch_assoc()): ?>
              <tr>
                <?php foreach ($prestamo as $campo => $valor):
                  if ($campo != $id_usuario_en_prestamos): // No mostrar la columna de ID de usuario
                    ?>
                    <td><?php echo htmlspecialchars($valor); ?></td>
                    <?php
                  endif;
                endforeach; ?>
              </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      <?php else: ?>
        <p>No hay préstamos registrados para este usuario.</p>
      <?php endif; ?>
    </div>
    <div class="info-row">
      <a href="cambiar_contrasena.php" class="change-password-button">Cambiar contraseña</a>
    </div>

  </div>
</body>

</html>

<?php
// Cerrar conexiones
$stmt_usuario->close();
if (isset($stmt_prestamos)) {
  $stmt_prestamos->close();
}
$conexion->close();
?>