<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'auth_functions.php';

$error = '';
$success = '';

// Procesar formulario de login
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    $usuario = $_POST['username'];
    $password = $_POST['password'];
    $rol = $_POST['rol'];
    

    if (loginUser($usuario, $password, $rol)) {
        // Redirigir según el rol
        switch ($rol) {
            case 1: // Administrador
                header("Location: inicio.html");
                break;
            case 2: // Almacenista
                header("Location: ./gestor_inventario/dashboard_gestor.html");
                break;
            case 3: // Docente
                header("Location: ./profesor/dashboard_profesor.html");
                break;
            case 4: // Técnico
                header("Location: ./mantenimiento1/dashboard_mantenimiento.html");
                break;
        }
        exit;
    } else {
        $error = "Usuario o contraseña incorrectos";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión - CTJFR</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;600&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://accounts.google.com/gsi/client" async></script>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <div class="row justify-content-center align-items-center min-vh-100">
            <div class="col-md-10">
                <div class="card login-card">
                    <div class="row g-0">
                        <div class="col-md-5 d-none d-md-block">
                            <div class="card-side-image"></div>
                        </div>
                        <div class="col-md-7">
                            <div class="card-body p-4">
                                <div class="text-center mb-4">
                                    <img src="imagenes/logo.png" alt="Logo" class="logo-img">
                                    <h2 class="mt-3">Iniciar Sesión</h2>
                                </div>
                                
                                <?php if ($error): ?>
                                <div class="alert alert-danger"><?php echo $error; ?></div>
                                <?php endif; ?>
                                
                                <?php if ($success): ?>
                                <div class="alert alert-success"><?php echo $success; ?></div>
                                <?php endif; ?>
                                
                                <ul class="nav nav-tabs mb-4" id="loginTabs" role="tablist">
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link active" id="admin-tab" data-bs-toggle="tab" data-bs-target="#admin-login" type="button" role="tab">Administrador</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="teacher-tab" data-bs-toggle="tab" data-bs-target="#teacher-login" type="button" role="tab">Profesor</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="gestor-tab" data-bs-toggle="tab" data-bs-target="#gestor-login" type="button" role="tab">Almacenista</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="maintenance-tab" data-bs-toggle="tab" data-bs-target="#maintenance-login" type="button" role="tab">Mantenimiento</button>
                                    </li>
                                </ul>
                                
                                <div class="tab-content" id="loginTabsContent">
                                    <!-- Administrador -->
                                    <div class="tab-pane fade show active" id="admin-login" role="tabpanel">
                                        <form method="post" action="">
                                            <input type="hidden" name="rol" value="1">
                                            <div class="mb-3">
                                                <label for="adminUsername" class="form-label">Usuario</label>
                                                <input type="text" class="form-control" id="adminUsername" name="username" required>
                                            </div>
                                            <div class="mb-3 position-relative">
                                                <label for="adminPassword" class="form-label">Contraseña</label>
                                                <input type="password" class="form-control" id="adminPassword" name="password" required>
                                                <button type="button" class="btn-show-password" onclick="togglePassword('adminPassword', this)">Mostrar</button>
                                            </div>
                                            <div class="mb-3 form-check">
                                                <input type="checkbox" class="form-check-input" id="rememberAdmin">
                                                <label class="form-check-label" for="rememberAdmin">Recordarme</label>
                                            </div>
                                            <button type="submit" name="login" class="btn btn-primary w-100">Iniciar Sesión</button>
                                        </form>
                                    </div>
                                    
                                    <!-- Profesor -->
                                    <div class="tab-pane fade" id="teacher-login" role="tabpanel">
                                        <form method="post" action="">
                                            <input type="hidden" name="rol" value="3">
                                            <div class="mb-3">
                                                <label for="teacherUsername" class="form-label">Usuario</label>
                                                <input type="text" class="form-control" id="teacherUsername" name="username" required>
                                            </div>
                                            <div class="mb-3 position-relative">
                                                <label for="teacherPassword" class="form-label">Contraseña</label>
                                                <input type="password" class="form-control" id="teacherPassword" name="password" required>
                                                <button type="button" class="btn-show-password" onclick="togglePassword('teacherPassword', this)">Mostrar</button>
                                            </div>
                                            <div class="mb-3 form-check">
                                                <input type="checkbox" class="form-check-input" id="rememberTeacher">
                                                <label class="form-check-label" for="rememberTeacher">Recordarme</label>
                                            </div>
                                            <button type="submit" name="login" class="btn btn-primary w-100">Iniciar Sesión</button>
                                        </form>
                                    </div>
                                    
                                    <!-- Gestor -->
                                    <div class="tab-pane fade" id="gestor-login" role="tabpanel">
                                        <form method="post" action="">
                                            <input type="hidden" name="rol" value="2">
                                            <div class="mb-3">
                                                <label for="gestorUsername" class="form-label">Usuario</label>
                                                <input type="text" class="form-control" id="gestorUsername" name="username" required>
                                            </div>
                                            <div class="mb-3 position-relative">
                                                <label for="gestorPassword" class="form-label">Contraseña</label>
                                                <input type="password" class="form-control" id="gestorPassword" name="password" required>
                                                <button type="button" class="btn-show-password" onclick="togglePassword('gestorPassword', this)">Mostrar</button>
                                            </div>
                                            <div class="mb-3 form-check">
                                                <input type="checkbox" class="form-check-input" id="rememberGestor">
                                                <label class="form-check-label" for="rememberGestor">Recordarme</label>
                                            </div>
                                            <button type="submit" name="login" class="btn btn-primary w-100">Iniciar Sesión</button>
                                        </form>
                                    </div>
                                    
                                    <!-- Mantenimiento -->
                                    <div class="tab-pane fade" id="maintenance-login" role="tabpanel">
                                        <form method="post" action="">
                                            <input type="hidden" name="rol" value="4">
                                            <div class="mb-3">
                                                <label for="maintenanceUsername" class="form-label">Usuario</label>
                                                <input type="text" class="form-control" id="maintenanceUsername" name="username" required>
                                            </div>
                                            <div class="mb-3 position-relative">
                                                <label for="maintenancePassword" class="form-label">Contraseña</label>
                                                <input type="password" class="form-control" id="maintenancePassword" name="password" required>
                                                <button type="button" class="btn-show-password" onclick="togglePassword('maintenancePassword', this)">Mostrar</button>
                                            </div>
                                            <div class="mb-3 form-check">
                                                <input type="checkbox" class="form-check-input" id="rememberMaintenance">
                                                <label class="form-check-label" for="rememberMaintenance">Recordarme</label>
                                            </div>
                                            <button type="submit" name="login" class="btn btn-primary w-100">Iniciar Sesión</button>
                                        </form>
                                    </div>
                                </div>
                                
                                <div class="mt-4 text-center">
                                    <p>¿No tienes cuenta? <a href="register.php">Regístrate</a></p>
                                    <p><a href="recover-password.php">¿Olvidaste tu contraseña?</a></p>
                                </div>
                                
                                <div class="mt-4">
                                    <p class="text-center">O inicia sesión con:</p>
                                    <div class="d-flex justify-content-center">
                                        <!-- Google Sign-In Button -->
                                        <div id="g_id_onload"
                                             data-client_id="208103662109-9coa5v23ukm0m3olrepau0qo90u7inln.apps.googleusercontent.com"
                                             data-context="signin"
                                             data-ux_mode="popup"
                                             data-callback="handleSignInWithGoogle"
                                             data-auto_select="true"
                                             data-itp_support="true"
                                             data-use_fedcm_for_prompt="true">
                                        </div>
                                        <div class="g_id_signin"
                                             data-type="standard"
                                             data-shape="pill"
                                             data-theme="outline"
                                             data-text="signin_with"
                                             data-size="large"
                                             data-logo_alignment="left">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function togglePassword(inputId, button) {
            const passwordInput = document.getElementById(inputId);
            const type = passwordInput.getAttribute("type") === "password" ? "text" : "password";
            passwordInput.setAttribute("type", type);
            button.textContent = type === "password" ? "Mostrar" : "Ocultar";
        }
        
        async function handleSignInWithGoogle(response) {
            // Enviar el token ID a nuestro backend para verificación
            try {
                const result = await fetch('google_auth.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        credential: response.credential
                    })
                });
                
                const data = await result.json();
                
                if (data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Inicio de sesión exitoso',
                        text: 'Bienvenido, ' + data.name,
                        confirmButtonText: 'Continuar'
                    }).then(() => {
                        window.location.href = data.redirect;
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: data.message,
                        confirmButtonText: 'Intentar de nuevo'
                    });
                }
            } catch (error) {
                console.error('Error:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Ocurrió un error al procesar la solicitud',
                    confirmButtonText: 'Intentar de nuevo'
                });
            }
        }
    </script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>