<?php
// Iniciar sesión
session_start();

// Si ya hay una sesión activa, redirigir al perfil
if (isset($_SESSION['id_usuario'])) {
    header("Location: perfil_usuario.php");
    exit();
}

// Variables para mensajes y manejo de errores
$error = "";
$usuario = "";

// Procesar el formulario cuando se envía
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Conexión a la base de datos
    $servidor = "localhost";
    $usuario_db = "root";
    $password_db = "";
    $base_datos = "sgit";

    $conexion = new mysqli($servidor, $usuario_db, $password_db, $base_datos);

    // Verificar conexión
    if ($conexion->connect_error) {
        die("Error de conexión: " . $conexion->connect_error);
    }

    // Obtener datos del formulario
    $usuario = $_POST['usuario'];
    $password = $_POST['password'];

    // Obtener nombres de columnas
    $sql_columnas = "SHOW COLUMNS FROM usuario";
    $resultado_columnas = $conexion->query($sql_columnas);

    $id_column = null;
    $nombre_column = null;
    $rol_column = null;
    $password_column = null;

    if ($resultado_columnas) {
        while ($columna = $resultado_columnas->fetch_assoc()) {
            if ($columna['Key'] == 'PRI') {
                $id_column = $columna['Field'];
            }

            $field_lower = strtolower($columna['Field']);

            if (strpos($field_lower, 'nombre') !== false && !$nombre_column) {
                $nombre_column = $columna['Field'];
            }
            if (strpos($field_lower, 'rol') !== false && !$rol_column) {
                $rol_column = $columna['Field'];
            }
            if (strpos($field_lower, 'contraseña') !== false || $field_lower === 'password') {
                $password_column = $columna['Field'];
            }
        }
    }

    // Valores predeterminados si no se encontraron
    if (!$id_column) {
        $posibles_ids = ['id_usuario', 'usuario_id', 'id', 'codigo', 'cod_usuario'];
        foreach ($posibles_ids as $posible_id) {
            $check_sql = "SHOW COLUMNS FROM usuario LIKE '$posible_id'";
            $check_result = $conexion->query($check_sql);
            if ($check_result && $check_result->num_rows > 0) {
                $id_column = $posible_id;
                break;
            }
        }
    }

    if (!$id_column) {
        $first_col_sql = "SHOW COLUMNS FROM usuario LIMIT 1";
        $first_col_result = $conexion->query($first_col_sql);
        if ($first_col_result && $first_col_result->num_rows > 0) {
            $first_col = $first_col_result->fetch_assoc();
            $id_column = $first_col['Field'];
        } else {
            die("No se pudo determinar la estructura de la tabla usuario");
        }
    }

    if (!$nombre_column)
        $nombre_column = 'Nombre_Usuario_1';
    if (!$rol_column)
        $rol_column = 'Id_Rol';
    if (!$password_column)
        $password_column = 'Contraseña';

    // Consulta para verificar credenciales
    $sql = "SELECT $id_column, $nombre_column, $rol_column, $password_column FROM usuario WHERE Usuario = ?";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("s", $usuario);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows == 1) {
        $usuario_data = $resultado->fetch_assoc();

        // Comparar contraseñas (plaintext)
        if ($usuario_data[$password_column] === $password) {
            // Si usas password_hash(), cambia por:
            // if (password_verify($password, $usuario_data[$password_column])) {
            $_SESSION['id_usuario'] = $usuario_data[$id_column];
            $_SESSION['nombre'] = $usuario_data[$nombre_column];
            $_SESSION['rol'] = $usuario_data[$rol_column];
            header("Location: perfil_usuario.php");
            exit();
        } else {
            $error = "Usuario o contraseña incorrectos";
        }
    } else {
        $error = "Usuario o contraseña incorrectos";
    }

    $stmt->close();
    $conexion->close();
}
?>


<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Iniciar Sesión</title>
</head>

<body>
<style>
    html, body {
        height: 100%;
        margin: 0;
        padding: 0;
    }

    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: #f4f7fe;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .login-container {
        background-color: white;
        padding: 40px 30px;
        border-radius: 12px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        width: 100%;
        max-width: 400px;
        text-align: center;
    }

    .system-name {
        font-size: 22px;
        color: #0a3d62;
        margin-bottom: 10px;
        font-weight: bold;
    }

    h1 {
        font-size: 26px;
        margin-bottom: 25px;
        color: #333;
    }

    .form-group {
        margin-bottom: 20px;
        text-align: left;
    }

    label {
        display: block;
        margin-bottom: 6px;
        color: #333;
        font-weight: 500;
    }

    input[type="text"],
    input[type="password"] {
        width: 100%;
        padding: 10px 14px;
        border: 1px solid #ccc;
        border-radius: 8px;
        font-size: 16px;
        box-sizing: border-box;
    }

    input[type="text"]:focus,
    input[type="password"]:focus {
        border-color: #2563eb;
        outline: none;
        box-shadow: 0 0 0 2px rgba(37, 99, 235, 0.2);
    }

    .error-message {
        color: #e74c3c;
        background-color: #ffe8e6;
        padding: 10px;
        border-radius: 8px;
        margin-bottom: 20px;
        font-weight: bold;
    }

    button[type="submit"] {
        background-color: #2563eb;
        color: white;
        border: none;
        padding: 12px 20px;
        border-radius: 8px;
        font-size: 16px;
        cursor: pointer;
        width: 100%;
        transition: background-color 0.3s ease;
    }

    button[type="submit"]:hover {
        background-color: #1e4fc3;
    }
</style>


    </style>
    <div class="login-container">
        <div class="system-name">Sistema SGIT</div>
        <h1>Iniciar Sesión</h1>

        <?php if (!empty($error)): ?>
            <div class="error-message"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="form-group">
                <label for="usuario">Usuario:</label>
                <input type="text" id="usuario" name="usuario" value="<?php echo htmlspecialchars($usuario); ?>"
                    required>
            </div>

            <div class="form-group">
                <label for="password">Contraseña:</label>
                <input type="password" id="password" name="password" required>
            </div>

            <button type="submit">Iniciar Sesión</button>
        </form>
    </div>
</body>

</html>