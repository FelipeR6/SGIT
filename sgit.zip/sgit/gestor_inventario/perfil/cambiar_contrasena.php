<?php
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['id_usuario'])) {
    header("Location: login.php");
    exit();
}

// Conexión a la base de datos
$conexion = new mysqli("localhost", "root", "", "sgit");
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

$mensaje = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['contrasena_actual'], $_POST['nueva_contrasena'], $_POST['confirmar_contrasena'])) {

    $id_usuario = $_SESSION['id_usuario'];
    $contrasena_actual = $_POST['contrasena_actual'];
    $nueva_contrasena = $_POST['nueva_contrasena'];
    $confirmar_contrasena = $_POST['confirmar_contrasena'];

    // Obtener la contraseña actual de la base de datos
    $sql = "SELECT Contraseña FROM usuario WHERE id_usuario = ?";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("i", $id_usuario);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado && $resultado->num_rows > 0) {
        $fila = $resultado->fetch_assoc();
        $contrasena_en_bd = $fila['Contraseña'];

        // Verificar si la contraseña actual ingresada coincide
        if ($contrasena_actual === $contrasena_en_bd) { // Usa password_verify si usas hash
            if ($nueva_contrasena === $confirmar_contrasena) {
                // Actualizar contraseña
                $sql_update = "UPDATE usuario SET Contraseña = ? WHERE id_usuario = ?";
                $stmt_update = $conexion->prepare($sql_update);
                $stmt_update->bind_param("si", $nueva_contrasena, $id_usuario);

                if ($stmt_update->execute()) {
                    $mensaje = "¡Contraseña actualizada correctamente!";
                } else {
                    $mensaje = "Error al actualizar la contraseña.";
                }
            } else {
                $mensaje = "Las contraseñas no coinciden.";
            }
        } else {
            $mensaje = "La contraseña actual es incorrecta.";
        }
    } else {
        $mensaje = "Usuario no encontrado.";
    }

    $stmt->close();
}

$conexion->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Cambiar Contraseña</title>
    <style>
        body {
            font-family: Arial;
            padding: 20px;
            background: #f2f2f2;
        }
        .form-container {
            max-width: 400px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px #ccc;
        }
        h2 {
            text-align: center;
        }
        label, input {
            display: block;
            width: 100%;
            margin-bottom: 10px;
        }
        input[type="password"] {
            padding: 8px;
        }
        .mensaje {
            margin-top: 10px;
            color: #d00;
            text-align: center;
        }
        .success {
            color: green;
        }
        button {
            padding: 10px;
            width: 100%;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
        }
        button:hover {
            background-color: #45a049;
        }
        .back-link {
            display: block;
            text-align: center;
            margin-top: 10px;
        }
    </style>
</head>
<body>
<div class="form-container">
    <h2>Cambiar Contraseña</h2>
    <form method="POST">
        <label for="contrasena_actual">Contraseña actual:</label>
        <input type="password" name="contrasena_actual" required>

        <label for="nueva_contrasena">Nueva contraseña:</label>
        <input type="password" name="nueva_contrasena" required>

        <label for="confirmar_contrasena">Confirmar nueva contraseña:</label>
        <input type="password" name="confirmar_contrasena" required>

        <button type="submit">Actualizar contraseña</button>
    </form>

    <?php if (!empty($mensaje)): ?>
        <div class="mensaje <?php echo strpos($mensaje, '¡') === 0 ? 'success' : ''; ?>">
            <?php echo $mensaje; ?>
        </div>
    <?php endif; ?>

    <a href="perfil_usuario.php" class="back-link">Volver al perfil</a>
</div>
</body>
</html>
