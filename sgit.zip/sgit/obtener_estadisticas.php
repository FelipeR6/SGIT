<?php
include 'conexion/conexion.php';

// Función para obtener el conteo de registros de una tabla
function obtenerConteo($conexion, $tabla)
{
    $query = "SELECT COUNT(*) as total FROM $tabla";
    $resultado = $conexion->query($query);
    $fila = $resultado->fetch_assoc();
    return $fila['total'];
}

// Obtener estadísticas generales
$totalEquipos = obtenerConteo($conexion, 'equipo');
$totalMantenimientos = obtenerConteo($conexion, 'mantenimiento');
$totalPrestamos = obtenerConteo($conexion, 'prestamo_equipo');
$totalUsuarios = obtenerConteo($conexion, 'usuario');

// Preparar respuesta JSON
$respuesta = [
    'totales' => [
        'equipos' => $totalEquipos,
        'mantenimientos' => $totalMantenimientos,
        'prestamos' => $totalPrestamos,
        'usuarios' => $totalUsuarios
    ]
];

// Devolver respuesta en formato JSON
header('Content-Type: application/json');
echo json_encode($respuesta);
?>