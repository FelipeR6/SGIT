<?php
require_once 'auth_functions.php';

// Recibir el token de Google
$input = json_decode(file_get_contents('php://input'), true);
$credential = $input['credential'] ?? null;

if (!$credential) {
    echo json_encode(['success' => false, 'message' => 'No se recibió credencial']);
    exit;
}

// Verificar el token con Google
$client_id = 'TU_CLIENT_ID_DE_GOOGLE'; // Reemplaza con tu Client ID
$client = new Google_Client(['client_id' => $client_id]);

try {
    // Obtener payload del token
    $payload = $client->verifyIdToken($credential);
    
    if ($payload) {
        $email = $payload['email'];
        $name = $payload['name'];
        
        // Verificar si el usuario existe en la base de datos
        global $conn;
        $stmt = $conn->prepare("SELECT * FROM usuario WHERE Correo_Usuario = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            // Usuario existe, iniciar sesión
            $user = $result->fetch_assoc();
            $_SESSION['user_id'] = $user['Id_Usuario'];
            $_SESSION['username'] = $user['Usuario'];
            $_SESSION['nombre'] = $user['Nombre_Usuario_1'] . ' ' . $user['Apellidos_Usuario_1'];
            $_SESSION['rol'] = $user['Id_Rol'];
            
            // Determinar redirección según rol
            $redirect = 'inicio.html';
            switch ($user['Id_Rol']) {
                case 2: // Almacenista
                    $redirect = './gestor_inventario/dashboard_gestor.html';
                    break;
                case 3: // Docente
                    $redirect = './profesor/dashboard_profesor.html';
                    break;
                case 4: // Técnico
                    $redirect = './mantenimiento1/dashboard_mantenimiento.html';
                    break;
            }
            
            echo json_encode([
                'success' => true,
                'name' => $name,
                'redirect' => $redirect
            ]);
        } else {
            // Usuario no existe, registrar automáticamente
            // Generar nombre de usuario a partir del email
            $username = explode('@', $email)[0];
            
            // Generar contraseña aleatoria
            $password = bin2hex(random_bytes(8));
            
            // Extraer nombres y apellidos del nombre completo
            $nameParts = explode(' ', $name);
            $nombre1 = $nameParts[0] ?? '';
            $nombre2 = $nameParts[1] ?? '';
            $apellido1 = $nameParts[2] ?? '';
            $apellido2 = $nameParts[3] ?? '';
            
            // Rol por defecto (3 - Docente)
            $rol = 3;
            
            $result = registerUser($username, $nombre1, $nombre2, $apellido1, $apellido2, '', '', $email, $password, $rol);
            
            if ($result === "success") {
                // Iniciar sesión con el nuevo usuario
                $_SESSION['user_id'] = $conn->insert_id;
                $_SESSION['username'] = $username;
                $_SESSION['nombre'] = $nombre1 . ' ' . $apellido1;
                $_SESSION['rol'] = $rol;
                
                echo json_encode([
                    'success' => true,
                    'name' => $name,
                    'redirect' => './profesor/dashboard_profesor.html'
                ]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Error al registrar usuario: ' . $result]);
            }
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Token inválido']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>