<?php
require_once 'auth_functions.php';

$error = '';
$success = '';

// Procesar formulario de registro
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['register'])) {
    $usuario = $_POST['username'];
    $nombre1 = $_POST['nombre1'];
    $nombre2 = $_POST['nombre2'] ?? '';
    $apellido1 = $_POST['apellido1'];
    $apellido2 = $_POST['apellido2'] ?? '';
    $telefono1 = $_POST['telefono1'];
    $telefono2 = $_POST['telefono2'] ?? '';
    $correo = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $rol = $_POST['rol'];
    
    // Validar que las contraseñas coincidan
    if ($password !== $confirm_password) {
        $error = "Las contraseñas no coinciden";
    } else {
        $result = registerUser($usuario, $nombre1, $nombre2, $apellido1, $apellido2, $telefono1, $telefono2, $correo, $password, $rol);
        
        if ($result === "success") {
            $success = "Registro exitoso. Ahora puedes iniciar sesión.";
        } else {
            $error = $result;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro - CTJFR</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;600&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <div class="row justify-content-center align-items-center min-vh-100">
            <div class="col-md-10">
                <div class="card login-card">
                    <div class="row g-0">
                        <div class="col-md-5 d-none d-md-block">
                            <div class="card-side-image"></div>
                        </div>
                        <div class="col-md-7">
                            <div class="card-body p-4">
                                <div class="text-center mb-4">
                                    <img src="imagenes/CTJFR.png" alt="Logo" class="logo-img">
                                    <h2 class="mt-3">Registro de Usuario</h2>
                                </div>
                                
                                <?php if ($error): ?>
                                <div class="alert alert-danger"><?php echo $error; ?></div>
                                <?php endif; ?>
                                
                                <?php if ($success): ?>
                                <div class="alert alert-success"><?php echo $success; ?></div>
                                <?php endif; ?>
                                
                                <form method="post" action="">
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="username" class="form-label">Nombre de Usuario</label>
                                            <input type="text" class="form-control" id="username" name="username" required>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="rol" class="form-label">Rol</label>
                                            <select class="form-select" id="rol" name="rol" required>
                                                <option value="">Seleccione un rol</option>
                                                <option value="1">Administrador</option>
                                                <option value="2">Almacenista</option>
                                                <option value="3">Docente</option>
                                                <option value="4">Técnico</option>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="nombre1" class="form-label">Primer Nombre</label>
                                            <input type="text" class="form-control" id="nombre1" name="nombre1" required>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="nombre2" class="form-label">Segundo Nombre</label>
                                            <input type="text" class="form-control" id="nombre2" name="nombre2">
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="apellido1" class="form-label">Primer Apellido</label>
                                            <input type="text" class="form-control" id="apellido1" name="apellido1" required>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="apellido2" class="form-label">Segundo Apellido</label>
                                            <input type="text" class="form-control" id="apellido2" name="apellido2">
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="telefono1" class="form-label">Teléfono Principal</label>
                                            <input type="tel" class="form-control" id="telefono1" name="telefono1" required>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="telefono2" class="form-label">Teléfono Secundario</label>
                                            <input type="tel" class="form-control" id="telefono2" name="telefono2">
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="email" class="form-label">Correo Electrónico</label>
                                        <input type="email" class="form-control" id="email" name="email" required>
                                    </div>
                                    
                                    <div class="mb-3 position-relative">
                                        <label for="password" class="form-label">Contraseña</label>
                                        <input type="password" class="form-control" id="password" name="password" required>
                                        <button type="button" class="btn-show-password" onclick="togglePassword('password', this)">Mostrar</button>
                                    </div>
                                    
                                    <div class="mb-3 position-relative">
                                        <label for="confirm_password" class="form-label">Confirmar Contraseña</label>
                                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                                        <button type="button" class="btn-show-password" onclick="togglePassword('confirm_password', this)">Mostrar</button>
                                    </div>
                                    
                                    <button type="submit" name="register" class="btn btn-primary w-100">Registrarse</button>
                                    
                                    <div class="mt-3 text-center">
                                        <p>¿Ya tienes cuenta? <a href="login.php">Iniciar Sesión</a></p>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function togglePassword(inputId, button) {
            const passwordInput = document.getElementById(inputId);
            const type = passwordInput.getAttribute("type") === "password" ? "text" : "password";
            passwordInput.setAttribute("type", type);
            button.textContent = type === "password" ? "Mostrar" : "Ocultar";
        }
    </script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>