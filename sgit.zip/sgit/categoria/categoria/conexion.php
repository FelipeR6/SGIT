<?php
$conexion = new mysqli( "localhost","root","","sgit");
$conexion->set_charset("utf8");
?>